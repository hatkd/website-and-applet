# 鱼皮编程学习路线

> 励志打造最贴心的编程学习路线

- [Java 学习路线](./docs/roadmap/Java学习路线.md)
- [前端学习路线](./docs/roadmap/前端学习路线.md)
- [Linux 学习路线](./docs/roadmap/Linux学习路线.md)
- [Python 学习路线](./docs/roadmap/Python学习路线.md)
- [大厂研发流程](./docs/roadmap/大厂研发流程.md)


更多学习路线近期上传~


### 思维导图获取

关注 [公众号【程序员鱼皮】](https://docs.qq.com/doc/DUFFRVWladXVjeUxW) ，后台回复【java】即可获取全部思维导图源文件，可以自由编辑。回复【软件】可获取思维导图阅读软件免费版。

> 其实有了 md 文件，使用 xmind 软件导入就能直接生成思维导图了。。。

### 想更好地学习编程？

最近鱼皮开了自己的付费编程学习圈子，在这里可以收获更多编程经验、和几千名小伙伴一起学习交流打卡、向鱼皮等大厂同学提问、看内部直播学会做项目等等。

点击了解详情：https://docs.qq.com/doc/DUG93dVNHbVZjZXpo

欢迎扫码加入 / 体验：

<img width="283" alt="image" src="https://user-images.githubusercontent.com/26037703/156210842-5623cee5-fbc0-4762-9a80-d3f048262089.png">

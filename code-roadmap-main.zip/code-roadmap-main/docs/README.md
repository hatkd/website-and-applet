# 鱼皮编程学习路线

> 励志打造最贴心的编程学习路线

- [Java 学习路线](roadmap/Java学习路线.md)
- [前端学习路线](roadmap/前端学习路线.md)
- [Linux 学习路线](roadmap/Linux学习路线.md)
- [Python 学习路线](roadmap/Python学习路线.md)
- [大厂研发流程](roadmap/大厂研发流程.md)
